package utp.agile.kerplank

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class KerplankApplicationTests {

}
