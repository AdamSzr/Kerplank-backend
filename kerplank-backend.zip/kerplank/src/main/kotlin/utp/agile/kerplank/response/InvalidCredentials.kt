package utp.agile.kerplank.response

class InvalidCredentials : FailResponse("złe dane do logowania",1000) {
}
