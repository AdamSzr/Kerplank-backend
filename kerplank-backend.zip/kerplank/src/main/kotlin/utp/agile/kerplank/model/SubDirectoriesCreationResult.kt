package utp.agile.kerplank.model

import java.io.File

data class SubDirectoriesCreationResult(val result: Result<File>, val errorMessage: String?)
