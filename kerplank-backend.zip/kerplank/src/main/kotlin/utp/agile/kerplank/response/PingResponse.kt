package utp.agile.kerplank.response


class PingResponse() : SuccessResponse()
