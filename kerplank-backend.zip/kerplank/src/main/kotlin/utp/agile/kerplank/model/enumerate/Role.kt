package utp.agile.kerplank.model.enumerate

enum class Role {
    USER, ADMIN
}