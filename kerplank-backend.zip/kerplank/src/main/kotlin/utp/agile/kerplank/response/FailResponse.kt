package utp.agile.kerplank.response

open class FailResponse(message: String, code: Number) : BaseResponse("fail")
