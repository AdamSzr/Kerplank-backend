package utp.agile.kerplank

const val TOKEN_PREFIX = "Bearer "

