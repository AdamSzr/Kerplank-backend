package utp.agile.kerplank.response

open class SuccessResponse : BaseResponse("ok")
