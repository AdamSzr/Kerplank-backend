package utp.agile.kerplank.model.enumerate

enum class ProjectStatus {
    ACTIVE,CLOSE
}
