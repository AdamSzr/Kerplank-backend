package utp.agile.kerplank.model.enumerate

enum class TaskStatus {
    NEW,
    IN_PROGRESS,
    DONE
}
